/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cafeshop;

/**
 *
 * @author Jannatul Tanzela
 */
public class data {

    public static String username1;
    public static String path;
    public static Integer id =0;
    public static String date;
    public static Integer cID;
    static String username;

    static class username {

        public username() {
        }
    }

    static class username1 {

        public username1() {
        }
    }

}
